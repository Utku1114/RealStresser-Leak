<?php 
	if($alert != "")
	{
		Alert($alert);
	}
?>